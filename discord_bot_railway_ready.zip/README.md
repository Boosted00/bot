# Discord Recruitment Bot

A Discord bot for tracking in-game hires, built with `discord.py`. Ready for Railway deployment.

## 🚀 Setup Instructions

1. Upload this project to a GitHub repository.
2. Go to [Railway](https://railway.app), create a new project, and link your GitHub repo.
3. Add an environment variable:
   - `DISCORD_TOKEN` = your bot token
4. Set your desired channel IDs and role name inside `main.py`.
5. Railway will automatically deploy and keep your bot online.

Enjoy!

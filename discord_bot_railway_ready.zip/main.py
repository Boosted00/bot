import discord
from discord.ext import commands, tasks
from discord import app_commands
import json, os, datetime, shutil

# === CONFIG ===
LOG_CHANNEL_ID = 123456789012345678  # replace with your #recruitment-logs channel ID
ERROR_LOG_CHANNEL_ID = 123456789012345678  # replace with your #error-logs channel ID
REQUIRED_ROLE_NAME = "Recruitment Cert"
HIRE_CAP = 10  # when to notify
DATA_FILE = "hire_data.json"
ARCHIVE_FOLDER = "archives"

# === BOT SETUP ===
intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)
tree = app_commands.CommandTree(bot)

# === HELPERS ===
def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

def get_month():
    return datetime.datetime.utcnow().strftime("%Y-%m")

def get_next_id(data, month):
    hires = data.get(month, {}).get("hires", [])
    return max((h["id"] for h in hires), default=0) + 1

def get_user_hires(data, month, user_id):
    return [h for h in data.get(month, {}).get("hires", []) if h["submitted_by"] == user_id]

def archive_month(month, data):
    if not os.path.exists(ARCHIVE_FOLDER):
        os.makedirs(ARCHIVE_FOLDER)
    with open(f"{ARCHIVE_FOLDER}/hires-{month}.json", "w") as f:
        json.dump(data.get(month, {}), f, indent=4)

# === EVENTS ===
@bot.event
async def on_ready():
    await tree.sync()
    print(f"Bot ready as {bot.user}")
    monthly_reset.start()

# === COMMANDS ===
@tree.command(name="hire", description="Log a new hire")
@app_commands.describe(employee_name="Name", employee_discord="Discord tag", employee_id="Character ID", employer="Employer name")
async def hire(interaction: discord.Interaction, employee_name: str, employee_discord: str, employee_id: str, employer: str):
    try:
        if REQUIRED_ROLE_NAME not in [r.name for r in interaction.user.roles]:
            await interaction.response.send_message("You lack the required role.", ephemeral=True)
            return

        data = load_data()
        month = get_month()
        if month not in data:
            data[month] = {"hires": [], "all_time": {}}

        hire_id = get_next_id(data, month)
        entry = {
            "id": hire_id,
            "employee_name": employee_name,
            "employee_discord": employee_discord,
            "employee_id": employee_id,
            "employer": employer,
            "submitted_by": interaction.user.id
        }

        data[month]["hires"].append(entry)
        data[month]["all_time"][employer] = data[month]["all_time"].get(employer, 0) + 1
        save_data(data)

        # Log embed
        channel = bot.get_channel(LOG_CHANNEL_ID)
        embed = discord.Embed(title="New Hire", color=0x2ecc71)
        for k, v in entry.items():
            if k != "submitted_by":
                embed.add_field(name=k.replace("_", " ").title(), value=str(v), inline=False)
        embed.set_footer(text=f"Logged by {interaction.user.display_name}")
        await channel.send(embed=embed)

        await interaction.response.send_message("Hire logged!", ephemeral=True)
        await interaction.user.send(f"You logged hire ID #{hire_id} for {employee_name}.")

        if len(get_user_hires(data, month, interaction.user.id)) == HIRE_CAP:
            await interaction.user.send(f"You hit the hire cap of {HIRE_CAP} this month!")

    except Exception as e:
        err_channel = bot.get_channel(ERROR_LOG_CHANNEL_ID)
        await err_channel.send(f"Error in /hire: {e}")

@tree.command(name="myhires", description="See how many hires you've logged")
async def myhires(interaction: discord.Interaction):
    data = load_data()
    month = get_month()
    count = len(get_user_hires(data, month, interaction.user.id))
    await interaction.response.send_message(f"You've logged {count} hire(s) this month.", ephemeral=True)

@tree.command(name="tophires", description="View top recruiters")
@app_commands.describe(scope="Choose 'monthly' or 'alltime'")
async def tophires(interaction: discord.Interaction, scope: str = "monthly"):
    data = load_data()
    month = get_month()

    if scope == "alltime":
        counter = {}
        for m in data.values():
            for e, c in m.get("all_time", {}).items():
                counter[e] = counter.get(e, 0) + c
        title = "All-Time Top Hires"
    else:
        counter = {}
        for h in data.get(month, {}).get("hires", []):
            e = h["employer"]
            counter[e] = counter.get(e, 0) + 1
        title = f"Top Hires - {month}"

    sorted_entries = sorted(counter.items(), key=lambda x: x[1], reverse=True)
    desc = "
".join([f"**{e}** — {c} hires" for e, c in sorted_entries])
    embed = discord.Embed(title=title, description=desc or "No data", color=0x3498db)
    await interaction.response.send_message(embed=embed)

@tree.command(name="hireedit", description="Edit a hire entry (admin only)")
async def hireedit(interaction: discord.Interaction, hire_id: int, field: str, new_value: str):
    if not interaction.user.guild_permissions.manage_messages:
        await interaction.response.send_message("No permission.", ephemeral=True)
        return

    data = load_data()
    month = get_month()
    for h in data.get(month, {}).get("hires", []):
        if h["id"] == hire_id:
            if field in h:
                h[field] = new_value
                save_data(data)
                await interaction.response.send_message(f"Hire #{hire_id} updated.", ephemeral=True)
                return
    await interaction.response.send_message("Hire not found or invalid field.", ephemeral=True)

@tree.command(name="removehire", description="Remove a hire entry (admin only)")
async def removehire(interaction: discord.Interaction, hire_id: int):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("No permission.", ephemeral=True)
        return

    data = load_data()
    month = get_month()
    hires = data.get(month, {}).get("hires", [])
    for i, h in enumerate(hires):
        if h["id"] == hire_id:
            del hires[i]
            save_data(data)
            await interaction.response.send_message(f"Hire #{hire_id} deleted.", ephemeral=True)
            return
    await interaction.response.send_message("Hire not found.", ephemeral=True)

@tasks.loop(hours=24)
async def monthly_reset():
    now = datetime.datetime.utcnow()
    if now.day == 1:
        data = load_data()
        month = get_month()
        if month in data:
            archive_month(month, data)
            data[month] = {"hires": [], "all_time": {}}
            save_data(data)

# === START ===
bot.run(os.getenv("DISCORD_TOKEN"))
